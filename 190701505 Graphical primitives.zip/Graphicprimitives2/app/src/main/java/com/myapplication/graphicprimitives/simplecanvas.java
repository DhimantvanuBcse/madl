package com.myapplication.graphicprimitives;

public class simplecanvas {
}
